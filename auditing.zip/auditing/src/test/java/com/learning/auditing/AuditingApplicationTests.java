package com.learning.auditing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditingApplicationTests {

	@Test
	void contextLoads() {
	}

}
