package com.learning.auditing;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.learning.auditing.config.APISuccessPayload;
import com.learning.auditing.entity.Student;
import com.learning.auditing.service.StudentService;

@SpringBootApplication
@RestController
@CrossOrigin
public class AuditingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditingApplication.class, args);
	}
	
	@Autowired 
	StudentService service;
	
	@GetMapping("/get")
	public ResponseEntity<APISuccessPayload> getAllStudents() {
		List<Student> list = service.getAllStudents();
		
		APISuccessPayload payload = APISuccessPayload.build(list, "yoyo" , HttpStatus.CREATED);
		ResponseEntity<APISuccessPayload> response = new ResponseEntity<APISuccessPayload>(payload, HttpStatus.CREATED);
		
		return  response;
	}
	
	@PostMapping("/add")
	public ResponseEntity<APISuccessPayload> addStudent(@RequestBody Student s) {
		
		service.addStudent(s);
		
		APISuccessPayload payload = APISuccessPayload.build("Student added", "yoyo" , HttpStatus.CREATED);
		ResponseEntity<APISuccessPayload> response = new ResponseEntity<APISuccessPayload>(payload, HttpStatus.CREATED);
		
		return  response;
		
	}
	
	

}
