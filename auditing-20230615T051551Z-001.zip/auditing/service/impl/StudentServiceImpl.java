package com.learning.auditing.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learning.auditing.entity.Student;
import com.learning.auditing.repository.StudentRepository;
import com.learning.auditing.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository repo;
	
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void addStudent(Student s) {
		// TODO Auto-generated method stub
		repo.save(s);
	}

	@Override
	public void updateStudent(Student s) {
		// TODO Auto-generated method stub
		repo.save(s);
	}
	
}
