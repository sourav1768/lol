package com.learning.auditing.service;

import java.util.List;

import com.learning.auditing.entity.Student;


public interface StudentService {
	public List<Student> getAllStudents();
	public void addStudent(Student s);
	public void updateStudent(Student s);
	
}
